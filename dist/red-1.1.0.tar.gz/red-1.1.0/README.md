<h1 align="center">
  <br>
  <img src="docs/image.jpg" alt="logo" width="300" height="300" style="border-radius: 50%; width: 300px; height: 300px; object-fit: cover;"/>
  <br>
 RED
  <br>
</h1>

<h4 align="center">Effortless container deployments to AWS.</h4>

<p align="center">
  <a href="https://rowlinsonmike.github.io/red/">Check out the Docs</a>
</p>
